from django.shortcuts import HttpResponse
def my_middleware(get_response):
    print('initialization')
    def middleware(request):
        print('before view')
        response=get_response(request)
        print('after view')
        return response
    return middleware

def my_middleware1(get_response):
    print('initialization')
    def middleware(request):
        print('before view')
        response=get_response(request)
        print('after view')
        return response
    return middleware

class FirstMiddleware():
    def __init__(self,get_response):
        self.get_response=get_response
        print('this is firstmiddleware')
    def __call__(self,request):
        print('firstcall before view')
        response = self.get_response(request)
        print("firstcall after view")
        return response

class SecondMiddleware():
    def __init__(self,get_response):
        self.get_response=get_response
        print('this is sec middleware')
    def __call__(self,request):
        print('sec call before view')
        response = self.get_response(request)
        print("sec call after view")
        return response

class MY_process():
    def __init__(self,get_response):
        self.get_response = get_response
        print('initialization view')
    def __call__(self,request):
        response = self.get_response(request)
        return response
    def process_view(request, *args, **kwagrs):
        print('this is a process view before')
        return HttpResponse('this is before view')

class ExceptionMiddleware():
    def __init__(self,get_response):
        self.get_response = get_response
        print('this is initialization')
    def __call__(self,request):
        print("before view")
        response = self.get_response(request)
        print('after view')
        return response

    def process_exception(self,request,exception):
        print('exception occured')
        msg = exception
        class_name = exception.__class__.__name__
        print(class_name)
        print(msg)
        return HttpResponse(msg)

class TemplateMiddleware():
    def __init__(self,get_response):
        self.get_response = get_response
        print('this is starting stage')
    def __call__(self,request):
        print('before view')
        response = self.get_response(request)
        print('after view')
        return response
    def Process_template_response(self,request,response):
        print('method')
        response.context_data['name']='swetha'
        return response