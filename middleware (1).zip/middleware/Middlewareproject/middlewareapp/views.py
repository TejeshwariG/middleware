from django.shortcuts import render,HttpResponse
from django.template.response import TemplateResponse

# Create your views here.
def show(request):
    print('this is view')
    return HttpResponse('this is home page')
def user_info(request):
 print("I am User Info View")
 context = {'name':'Rahul'}
 return TemplateResponse(request, 'user.html', context)